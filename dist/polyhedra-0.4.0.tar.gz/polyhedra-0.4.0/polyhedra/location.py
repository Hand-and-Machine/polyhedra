import os

__location__ = os.path.dirname(__file__)
